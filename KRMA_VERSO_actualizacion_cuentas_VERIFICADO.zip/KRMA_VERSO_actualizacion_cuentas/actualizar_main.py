#!/usr/bin/env python3
"""Aplica +$3.000 COP al precio público de cuentas completas en un backend FastAPI.

Uso: python actualizar_main.py /ruta/a/main.py
Crea main_actualizado.py junto al original y no modifica el archivo de entrada.
"""
from pathlib import Path
import sys

INCREASE_COP = 3000

HELPER = '''def is_complete_account_product(product):
    category = (getattr(product, "category", "") or "").strip().lower()
    name = (getattr(product, "name", "") or "").strip().lower()

    # La categoría debe identificar explícitamente cuentas completas.
    if category in {"cuentas", "cuenta", "accounts", "account", "cuentas completas", "complete accounts"}:
        return True

    markers = (
        "cuenta completa", "cuentas completas", "cuenta full",
        "full account", "account complete", "cuenta completo",
    )
    return any(marker in name for marker in markers)


def get_public_product_price(product):
    if product.price is None:
        return None
    price = float(product.price)
    if is_complete_account_product(product):
        price += 3000
    return price


'''


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python actualizar_main.py /ruta/a/main.py")

    source = Path(sys.argv[1]).expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"No existe el archivo: {source}")

    code = source.read_text(encoding="utf-8")
    catalog_marker = '@app.get("/api/catalog")\ndef get_catalog(db: Session = Depends(get_db)):'

    if "def get_public_product_price(product):" not in code:
        if catalog_marker not in code:
            raise SystemExit("No encontré la ruta /api/catalog con la firma esperada. No se creó ningún archivo.")
        code = code.replace(catalog_marker, HELPER + catalog_marker, 1)

    old_catalog_price = '"price": product.price,\n            "precio": product.price,'
    new_catalog_price = '"price": get_public_product_price(product),\n            "precio": get_public_product_price(product),'
    if old_catalog_price in code:
        code = code.replace(old_catalog_price, new_catalog_price, 1)
    elif new_catalog_price not in code:
        raise SystemExit("No encontré los dos campos de precio del catálogo. No se creó ningún archivo.")

    old_order_price = '            total = float(product.price) * data.quantity'
    new_order_price = '            public_price = get_public_product_price(product)\n            total = public_price * data.quantity'
    if old_order_price in code:
        code = code.replace(old_order_price, new_order_price, 1)
    elif new_order_price not in code:
        raise SystemExit("No encontré el cálculo del pedido normal. No se creó ningún archivo.")

    destination = source.with_name("main_actualizado.py")
    destination.write_text(code, encoding="utf-8")
    print(f"Archivo actualizado creado: {destination}")
    print("El archivo de entrada quedó intacto.")


if __name__ == "__main__":
    main()
