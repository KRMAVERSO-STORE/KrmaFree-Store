KRMA VERSO STORE — PAQUETE DE REDISEÑO PREMIUM
================================================

Sitio de referencia:
https://krmaverso-store.github.io/KrmaFree-Store/

Qué cambia en esta versión
--------------------------
- Rediseño visual global: portada, navegación, tarjetas, botones, buscadores y espacios.
- Diseño responsive ajustado para móvil y escritorio.
- Tarjetas de productos digitales con logotipos SVG de marca mediante Simple Icons CDN.
- Si un logotipo no está disponible, aparece el nombre de la marca como alternativa.
- La sección Tecnología y accesorios permanece separada de la sección Vapes.
- En Inicio se agregó un acceso independiente a Vapes.
- Se incorporó catalogo-minorista.json con los 38 registros del PDF de precios.
- Se actualizaron precios coincidentes y se añadieron variantes que no estaban en el seed inicial.

Imágenes y marcas
-----------------
Los logotipos digitales se solicitan desde https://cdn.simpleicons.org/ (proyecto Simple Icons).
Requieren conexión a Internet en el navegador. Los logotipos y marcas pertenecen a sus respectivos titulares.
Su presencia identifica el servicio y no implica afiliación, patrocinio ni autorización comercial.
No se han sustituido las fotografías de productos físicos por imágenes de fabricante que pudieran
representar erróneamente referencias de terceros. Se conservaron las fotografías recibidas.
En el catálogo físico hay 55 referencias: 32 de tecnología/accesorios y 23 de Vapes.
Dos referencias de Vapes no tienen imagen en el archivo de origen; no se inventó una fotografía.

Catálogo minorista
------------------
El PDF se adjuntó dos veces y ambos archivos contienen el mismo catálogo. Se tomó una sola copia.
El documento indica que el precio KrmaVerso se calcula como precio observado + $3.000 COP.
Los 38 registros están en catalogo-minorista.json.
Los renglones con datos parcialmente visibles llevan confirm_before_sale=true y deben confirmarse
con el proveedor antes de ofrecerlos.

IMPORTANTE: publicación y base de datos
---------------------------------------
Este ZIP no modifica GitHub ni publica cambios por sí solo.
Para publicar el rediseño, sube el contenido del ZIP a la raíz del repositorio correcto
y confirma el commit.

El sitio consulta el catálogo en el backend mediante /api/catalog. catalog_seed.json se usa
solo cuando la base de datos se crea vacía. Si la base de datos de producción ya tiene productos,
cambiar catalog_seed.json NO actualiza automáticamente los precios existentes. Es necesario
sincronizar los 38 registros con el backend/base de datos y verificar el resultado antes de vender.

No se modificaron secretos ni se añadieron credenciales. Mantén las claves de Wompi y del backend
fuera del repositorio público.
