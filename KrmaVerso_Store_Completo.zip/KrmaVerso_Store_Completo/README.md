# KrmaVerso Store — Paquete Completo (v2)

## Archivos incluidos en este ZIP
1. `main13.html`: Estructura principal de la tienda con diseño oscuro/neón, buscador en tiempo real, filtros por categoría, modal de vista rápida, carrito persistente y checkout directo a WhatsApp.
2. `productos.js`: Base de datos de productos separada (incluye la categoría **Algodón & Streetwear**, Accesorios, Tecnología y Digitales) para que puedas actualizar precios, fotos y stock sin tocar el HTML.
3. `README.md`: Instrucciones de despliegue.

## Configuración rápida en 2 pasos
1. Sube tanto `main13.html` como `productos.js` a la misma carpeta de tu repositorio en GitHub (`KrmaFree-Store`).
2. Abre `main13.html` y cambia `const WHATSAPP_PHONE = "573000000000";` por tu número de WhatsApp real.
