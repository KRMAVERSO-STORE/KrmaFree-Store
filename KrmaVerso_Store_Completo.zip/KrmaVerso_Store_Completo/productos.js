// =========================================================
// CATÁLOGO DE PRODUCTOS KRMAVERSO (Incluye Línea Algodón)
// =========================================================
// Edita este archivo para agregar, modificar o quitar productos
// sin tener que tocar el código HTML de main13.html.

const PRODUCTS = [
  {
    id: 1,
    name: "Hoodie Oversize Algodón Perchado 380gr",
    category: "Algodón & Streetwear",
    price: 115000,
    badge: "100% ALGODÓN",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=800&q=80",
    description: "Buzo oversize en algodón pesado perchado de 380gr, suave al tacto y con estampado neón de alta densidad. Tallas S, M, L y XL."
  },
  {
    id: 2,
    name: "Camiseta Boxy Fit Algodón Peinado 240gr",
    category: "Algodón & Streetwear",
    price: 68000,
    badge: "ALGODÓN PREMIUM",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80",
    description: "Camiseta corte boxy fit 100% algodón peinado de alto gramaje, cuello acanalado grueso que no se deforma."
  },
  {
    id: 3,
    name: "Jogger Cargo Algodón French Terry",
    category: "Algodón & Streetwear",
    price: 98000,
    badge: "NUEVO",
    image: "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?auto=format&fit=crop&w=800&q=80",
    description: "Pantalón cargo en algodón burda French Terry con bolsillos laterales amplios y ajuste en bota."
  },
  {
    id: 4,
    name: "Pack x3 Camisetas Básicas Algodón Krma",
    category: "Algodón & Streetwear",
    price: 145000,
    badge: "COMBO AHORRO",
    image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=800&q=80",
    description: "Paquete de 3 camisetas esenciales 100% algodón (Negro, Blanco y Gris Carbón). Ideales para uso diario."
  },
  {
    id: 5,
    name: "Gorra Trucker KrmaVerso Edition",
    category: "Accesorios",
    price: 45000,
    badge: "TOP VENTAS",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=800&q=80",
    description: "Gorra edición limitada con bordado 3D frontal, malla transpirable y ajuste trasero reforzado."
  },
  {
    id: 6,
    name: "Audífonos Gamer RGB Pro",
    category: "Tecnología",
    price: 135000,
    badge: "ENVÍO GRATIS",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80",
    description: "Sonido envolvente 7.1, micrófono con cancelación de ruido e iluminación dinámica RGB."
  },
  {
    id: 7,
    name: "Combo Streaming & Gaming 1 Mes",
    category: "Digitales",
    price: 25000,
    badge: "ENTREGA INMEDIATA",
    image: "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?auto=format&fit=crop&w=800&q=80",
    description: "Acceso garantizado por 30 días con soporte inmediato y renovación directa por WhatsApp."
  },
  {
    id: 8,
    name: "Reloj Smart Fit Ultra Negro",
    category: "Tecnología",
    price: 120000,
    badge: "OFERTA",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80",
    description: "Pantalla AMOLED, notificaciones en tiempo real, resistencia al agua y batería de hasta 7 días."
  }
];
